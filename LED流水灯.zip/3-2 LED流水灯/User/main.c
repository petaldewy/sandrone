#include <stdint.h>

//�Ĵ����궨��
#define RCC_APB2ENR   *(volatile uint32_t *)(0x40021018)
#define GPIOA_CRL     *(volatile uint32_t *)(0x40010800)
#define GPIOB_CRL     *(volatile uint32_t *)(0x40010C00)
#define GPIOC_CRH     *(volatile uint32_t *)(0x40011004)
#define GPIOA_BSRR    *(volatile uint32_t *)(0x40010810)
#define GPIOB_BSRR    *(volatile uint32_t *)(0x40010C10)
#define GPIOC_BSRR    *(volatile uint32_t *)(0x40011010)

//��ʱ
void Delay_1s(void) {
    for (uint32_t i = 0; i < 10000000; i++) {
        __asm("nop"); 
    }
}

//������
int main(void) {
    // ʱ��
    RCC_APB2ENR |= (1 << 2) | (1 << 3) | (1 << 4);

    // ����ģʽ��2MHZ�����
    GPIOA_CRL &= ~(0xF << 4);  GPIOA_CRL |= (0x2 << 4);   
    GPIOB_CRL &= ~(0xF << 20); GPIOB_CRL |= (0x2 << 20);  
    
    GPIOC_CRH &= ~(0xF << 20); GPIOC_CRH |= (0x2 << 20);  
    GPIOC_CRH &= ~(0xF << 24); GPIOC_CRH |= (0x2 << 24);  

    GPIOA_BSRR = (1 << 1);  
    GPIOB_BSRR = (1 << 5);  
    GPIOC_BSRR = (1 << 13) | (1 << 14); 
		//��ˮ��
    while (1) {
		// PA1��
        GPIOA_BSRR = (1 << 17); Delay_1s(); GPIOA_BSRR = (1 << 1);
    // PB5��    
        GPIOB_BSRR = (1 << 21); Delay_1s(); GPIOB_BSRR = (1 << 5);
        
    // PC13��PC14һ����    
        GPIOC_BSRR = (1 << 29) | (1 << 30); 
        Delay_1s(); 
        
    // PC13��PC14һ����   
        GPIOC_BSRR = (1 << 13) | (1 << 14); 
    }
}