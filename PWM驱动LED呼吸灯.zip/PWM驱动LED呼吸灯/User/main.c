#include "stm32f10x.h"

// 配置 TIM2_CH1 (PA0) 输出PWM
void TIM2_PWM_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    TIM_OCInitTypeDef  TIM_OCInitStructure;
    
    // 1. 开启时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); // GPIOA 挂在 APB2
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);  // TIM2 挂在 APB1
    
    // 2. 配置 PA0 为复用推挽输出
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    // 3. 配置定时器时基单元 (目标：2秒周期)
    TIM_TimeBaseStructure.TIM_Period = 19999;        // ARR: 2秒周期
    TIM_TimeBaseStructure.TIM_Prescaler = 7199;      // PSC: 72MHz->10kHz
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
    
    // 4. 配置PWM输出模式 (通道1)
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = 10000;           // CCR: 10000/20000 = 50%占空比
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
    TIM_OC1Init(TIM2, &TIM_OCInitStructure);
    
    // 5. 使能预装载和定时器
    TIM_OC1PreloadConfig(TIM2, TIM_OCPreload_Enable);
    TIM_ARRPreloadConfig(TIM2, ENABLE);
    TIM_Cmd(TIM2, ENABLE);
}

int main(void)
{
    TIM2_PWM_Init();
    
    while(1)
    {
        // 硬件自动输出PWM，LED以2秒周期亮灭
    }
}
/*#include "stm32f10x.h"

void TIM2_PWM_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    TIM_OCInitTypeDef  TIM_OCInitStructure;
    
    // 1. 开启时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); // GPIO
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);  // TIM2 挂在 APB1
    
    // 2. 配置 PA0 为复用推挽输出
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    // 3. 配置定时器时基单元 (目标：2秒周期)
    TIM_TimeBaseStructure.TIM_Period = 999;        // ARR: 2秒周期
    TIM_TimeBaseStructure.TIM_Prescaler = 71;      // PSC: 72MHz->10kHz
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
    
    // 4. 配置PWM输出模式 (通道1)
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = 0;           // CCR: 10000/20000 = 50%占空比
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
    TIM_OC1Init(TIM2, &TIM_OCInitStructure);
    
    // 5. 使能预装载和定时器
    TIM_OC1PreloadConfig(TIM2, TIM_OCPreload_Enable);
    TIM_ARRPreloadConfig(TIM2, ENABLE);
    TIM_Cmd(TIM2, ENABLE);
}
int main(void)
{
    uint16_t pwm_val = 0; 
    uint8_t dir = 1;      // 1:渐亮, 0:渐暗
    
    TIM2_PWM_Init();
    
    while(1)
    {
        TIM_SetCompare1(TIM2, pwm_val); // 更新占空比
        
        if(dir == 1) 
        {
            pwm_val += 10;              // 步进改为 10 (数值越小越平滑)
            if(pwm_val >= 999) dir = 0; // 达到最大值 999 (最亮)
        }
        else 
        {
            pwm_val -= 10; 
            if(pwm_val <= 0) dir = 1;   // 达到最小值 0 (最暗)
        }
        
        Delay_ms(10); // 关键：延时改为10ms。100步*10ms=1秒(单向)，2秒一个完整周期
    }
}
*/